#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include <direct.h>

//Physical constant
#define PI 3.141592653589793	//pi
#define MP 1.6605655e-27	// MP=1.6605655e-27[kg] Weight of proton
#define NAV  6.022045e23	// NAV=6.022045e23[1/mol] Avogadro number */
#define K   1.380662e-23	// K=1.380662e-23[J/K] Boltzmann's constant */
#define R 8.31441		// R=8.31441[J/K/mol] gas constant */
#define E 1.6021892e-19		//  E=1.6021892e-19[C] Elementary electric charge */
#define C 2.9979246e8		//  C = 2.9979246e8 [m/s] light velocity  */
#define H 6.626176e-34		//  H = 6.626176e-34 [Js] Planck's constant  */
#define Cbn 25.0       //Cbn=25.0[ppm] Boron concentration in normal cells
#define RBEthrm 2.9   //RBE=2.9 Relative biologic effectiveness for thermal neutron
#define RBEfast 2.4   //RBE=2.4 Relative biologic effectiveness for fast neutron
#define CBEn 1.34     //CBEn=1.35 Compound biological effectiveness (CBE) of normal cells
#define CBEt 4.0      //CBEt=3.8  Compound biological effectiveness (CBE) of tumor cells
#define TNR 3.5       //Tumor/normal ratio of boron concentration

#define BYTE 256		// 1 byte

typedef struct _Seng_tab
{	
	char buf[BYTE];
} Seng_tab;

int main(int argc, char *argv[])
{
	FILE *fp, *fpo;

	Seng_tab *eng_tab;
	
	char buf[BYTE];
	char filename[BYTE], outfile[BYTE];
	char dum[BYTE];

	int flg;
	int i,j,k,l,n;
	int num_tab, num_gker;
	
	float val, val1, val2, val3, val4;
	float *eng_gker;
	float *gkerma;
	float el, eu, gf, err;
	float **gd;

//fpo = fopen("out.txt","w");

//	flg=0;
//	if(argc>1)
//	{
//		sscanf(argv[1],"%s",&flnm0);
//	}

// counting number of data
	sprintf(filename,"./eng-list.txt");
	if((fp=fopen(filename,"r"))==NULL)
	{
		printf("%s can't be opened.\n",filename);
		return -100;
	}
	i = 0;
	fgets(dum,256,fp);
	while(fgets(dum,256,fp)!=NULL)
	{
		i++;
	}
	num_tab = i;
	fclose(fp);
	
	sprintf(filename,"gkerma_AI.txt");
	if((fp=fopen(filename,"r"))==NULL)
	{
		printf("%s can't be opened.\n",filename);
		return -100;
	}
	i = 0;
	fgets(dum,256,fp);
	while(fgets(dum,256,fp)!=NULL)
	{
		i++;
	}
	num_gker = i;
	fclose(fp);

//allocating data array
	gkerma = (float *)malloc(sizeof(float)*(float)num_gker);
	eng_tab = (Seng_tab *)malloc(sizeof(Seng_tab)*num_tab);
	eng_gker = (float *)malloc(sizeof(float)*num_gker);

//reading data
	sprintf(filename,"./eng-list.txt");
	if((fp=fopen(filename,"r"))==NULL)
	{
		printf("%s can't be opened.\n",filename);
		return -100;
	}
	i=0;
	fgets(dum,256,fp);
	while(fgets(dum,256,fp)!=NULL)
	{
		if(i>num_tab)
		{
			printf("Reading process reached EOF.\n");
			return -999;
		}
		sscanf(dum,"%s", eng_tab[i].buf);
		i++;
	}
	fclose(fp);

	sprintf(filename,"gkerma_AI.txt");
	if((fp=fopen(filename,"r"))==NULL)
	{
		printf("%s can't be opened.\n",filename);
		return -100;
	}
	i=0;
	fgets(dum,256,fp);
	while(fgets(dum,256,fp)!=NULL)
	{
		if(i>num_gker)
		{
			return -999;
		}
		
		sscanf(dum,"%f %f %f %f %f", &val, &val1, &val2, &val3, &val4);
		eng_gker[i]   = val;
		gkerma[i]     = val4;

		i++;
	}
	fclose(fp);

//loading table data
	int ge_tab=100;
	int num_tally=200;
	//gamma-ray dose
	float gd_d;
	gd = (float **)malloc(sizeof(float)*num_tab);
	for(i=0;i<num_tab;i++){
		gd[i]=(float *)malloc(sizeof(float)*num_tally);
		for(j=0;j<num_tally;j++) gd[i][j]=0.0;		//gd[input energy][depth]
	}
	char path2tab[]="./PHITSresults";
	for (i=0;i<num_tab;i++){	//input energy loop
		l=0;
		sprintf(filename,"%s/%sMeV-gspe.dat",path2tab,eng_tab[i].buf);
		if((fp=fopen(filename,"r"))==NULL)
		{
			printf("%s can't be opened.\n",filename);
			return -100;
		}
		printf("%s is successfully opened.\n",filename);
		flg=0;
		while(l<num_tally)
		{
			while(flg==0)
			{
				sprintf(buf,"\n");
				fgets(dum,256,fp);
				sscanf(dum,"%s %s",&buf,&buf);
				if(strncmp(buf,"e-lower",7)==0)
				{
					flg=1;
				}
			}

			int kl, ku;
			float ave;
			float gkerma_e;
			gd_d=0.0;
			for(j=0;j<ge_tab;j++)
			{
				
				float gd_de;
				fgets(dum,256,fp);
				sscanf(dum,"%f %f %f %f",&el,&eu,&gf,&err);

				kl = 0;
				ku = 1;
				ave = exp( (log(el)+log(eu))*0.5 );
				for(k=0;k<num_gker;k++)
				{
					if(ave>eng_gker[k])
					{
						kl = k;
						ku = k+1;
					}
				}
				if(ku>=num_gker)
				{
					ku = num_gker-1;
					kl = num_gker-2;
				}
				gkerma_e = exp( log(gkerma[kl])+(log(gkerma[ku])-log(gkerma[kl]))/(log(eng_gker[ku])-log(eng_gker[kl]))*(log(ave)-log(eng_gker[kl])) );
				gd_d+=gkerma_e*gf;								//Gamma RBE dose 
				flg=0;
			}
			gd[i][l]=gd_d;	//i:mono-eng, l:depth
			l++;
		}
		fclose(fp);
	}
//This is the end of common discription
//write file
	char path2ndose[]="./gdose";
	for(i=0;i<num_tab;i++){
		sprintf(filename,"%s/%03d-gdose.dat",path2ndose,i);
		fp=fopen(filename,"w");
		fprintf(fp,"#Eng=%sMeV\n#column1:depth[mm]\n#column2:G-dose[pGy/source]\n",eng_tab[i].buf);
		fprintf(fp,"#constants:Cb(N)=%.1fppm, RBE for thermal neutron=%.1f, RBE for fast neutron=%.1f, CBE(N)=%.2f, CBE(T)=%.1f, T/N=%.1f\n",Cbn,RBEthrm,RBEfast,CBEn,CBEt,TNR);
		for(j=0;j<num_tally;j++){
			fprintf(fp,"%i\t%10.4e\n",j,gd[i][j]);
		}
		fclose(fp);
	}


// release memory
	free(gkerma);
	free(eng_tab);
	free(eng_gker);
	free(gd);
	for(i=0;i<num_tab;i++){
		free(gd[i]);
	}
	
//	fclose(fpo);
	return 1;
}
